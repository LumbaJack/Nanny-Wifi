/* 
 * File:   main.cpp
 * Author: jacksalien
 *
 * Created on December 22, 2014, 10:06 AM
 */

#include "program.h"

#include <fstream>
#include <string.h>
#include <dirent.h>
#include <iostream>
#include <algorithm>
#include <stdexcept>
#include <sys/stat.h>

//////////////////////////////////////////////////////////////////////////////

Program::Program()
    : m_rvalue( 0 )
    , m_tolaranceLevel( 50 )
    , m_currentSiteGoodWeightLevel( 0 )
    , defaultCategoryFolder( "./phraselists/categories" )
    , goodWordsCategoryFolder( "./phraselists/goodphrases" )
{
    //**************Configuration file loading**************
    std::ifstream stream("configFile.conf");
    
    if(!stream){
        std::cout << "No configuration file found." << std::endl;
    } else{
        parseConfig(stream);
    }
    //******************************************************    
    
    //**************Load enabled categories**************
    loadCategories(defaultCategoryFolder, true, "", false);
    loadCategories(goodWordsCategoryFolder, true, "", true);
    //***************************************************   
}

Program::~Program()
{
}

int
Program::GetRvalue()
{
    return m_rvalue;
}

int
Program::execute( std::string siteContents )
{
    m_rvalue = RETURN_SUCCESS;
    //siteContents = stripHtmlTags(siteContents);
    
    if(siteContents.length() > 0){
        if(validateAgainstCategories(siteContents)){
            m_rvalue = ADULT_CONTENT;
        }
    } else{
        std::cout<<"No Contents Found"<<std::endl;
        m_rvalue = MISSING_SITE_CONTENTS;
    }

    return m_rvalue;
}

bool
Program::validateAgainstCategories(std::string contents)
{
    bool results = false;
    bool goodSectionSet = false;
    
    std::transform(contents.begin(), contents.end(), contents.begin(), ::tolower);

    for(int i=0; i<catMainContainer.size(); i++){
        m_currentSiteWeightLevel = 0;
        
        checkSingleLevelWeights(contents, catMainContainer[i].singleContainerVec);
        checkMultiLevelWeights(contents, catMainContainer[i].multiContainerVec);
        
        if (m_currentSiteWeightLevel > m_tolaranceLevel){
            if(goodSectionSet){
                m_currentSiteWeightLevel += m_currentSiteGoodWeightLevel;
                
                if (m_currentSiteWeightLevel > m_tolaranceLevel){
                    failedSections.push_back(catMainContainer[i].categoryClass);
                    results = true;
                }
            } else{
                goodSectionSet = true;
                int currentValue = m_currentSiteWeightLevel;
                m_currentSiteWeightLevel = 0;
                
                checkSingleLevelWeights(contents, goodMainContainer[0].singleContainerVec);
                checkMultiLevelWeights(contents, goodMainContainer[0].multiContainerVec);
                
                m_currentSiteGoodWeightLevel += m_currentSiteWeightLevel;
                m_currentSiteWeightLevel += currentValue;
                
                if (m_currentSiteWeightLevel > m_tolaranceLevel){
                    failedSections.push_back(catMainContainer[i].categoryClass);
                    results = true;
#ifdef DEBUG
std::cout<<"Found section: "<<catMainContainer[i].categoryClass<<std::endl;
std::cout<<"Total: "<<m_currentSiteWeightLevel<<std::endl;
#endif
                }
            }
        }
    }
    
    return results;
}

void
Program::checkSingleLevelWeights(std::string contents, std::vector<std::string> singleLevelWeights)
{  
    std::transform(contents.begin(), contents.end(), contents.begin(), ::tolower);
 
    for(int i=0; i<singleLevelWeights.size(); i++){
        int weightValue = 0;
        std::string weightString;
        std::string delimiter = "><";
        std::string::size_type start_position = 0;

        std::string token;
        while ((start_position = singleLevelWeights[i].find(delimiter)) != std::string::npos) {
            token = singleLevelWeights[i].substr(0, start_position);
            weightString = token.erase(0, 1);
            singleLevelWeights[i].erase(0, start_position + delimiter.length());
        }
        weightValue = atoi(singleLevelWeights[i].erase(singleLevelWeights[i].size()-1).c_str());

        if(weightString.length() > 0 and weightValue != 0){
            std::transform(weightString.begin(), weightString.end(), weightString.begin(), ::tolower);
            if(contents.find(weightString) != std::string::npos){
#ifdef DEBUG
//std::cout<<"'"<<weightString<<"'"<<":"<<weightValue<<std::endl;
#endif
                m_currentSiteWeightLevel += weightValue;
            }
        }
    }
}

void
Program::checkMultiLevelWeights(std::string contents, std::vector<std::string> multiLevelWeights)
{
    int weightValue;
    std::string token;
    std::string tempWeightString;
    std::vector<std::string> weightString;
            
    for(int i=0; i<multiLevelWeights.size(); i++){
        bool found = true;
        std::string delimiter = "><";
        std::string seconddelimiter = ">,<";
        std::string::size_type start_position = 0;

        while ((start_position = multiLevelWeights[i].find(delimiter)) != std::string::npos) {
            token = multiLevelWeights[i].substr(0, start_position);
            tempWeightString = token.erase(0, 1);
            multiLevelWeights[i].erase(0, start_position + delimiter.length());
        }
        weightValue = atoi(multiLevelWeights[i].erase(multiLevelWeights[i].size()-1).c_str());
        
        while ((start_position = tempWeightString.find(seconddelimiter)) != std::string::npos) {
            token = tempWeightString.substr(0, start_position);
            weightString.push_back(token);
            tempWeightString.erase(0, start_position + seconddelimiter.length());
        }
        weightString.push_back(tempWeightString);

        if(weightString.size() > 0 and weightValue > 0){
            for(int i=0;i<weightString.size();i++){
                if(contents.find(weightString[i]) == std::string::npos){
                    found = false;
                    break;
                }
            }
            if(found){
                m_currentSiteWeightLevel += weightValue;
#ifdef DEBUG
for(int i=0;i<weightString.size();i++){
    std::cout<<"'"<<weightString[i]<<"'"<<":";
}
std::cout<<weightValue<<std::endl;
#endif
            }
        }
    }
}

void
Program::parseConfig(std::ifstream & cfgfile)
{
    options.clear();
    std::string id, eq, val;

    while(cfgfile >> id >> eq >> val) {
        if (id[0] == '#'){
            continue;
        }
        
        if (id == "tolaranceLevel"){
            m_tolaranceLevel = atoi(val.c_str());
        }

        if (eq != "=") {
            m_rvalue = BAD_CONFIG_FILE;
            std::cout<<"Configuration parse error."<<std::endl;
            throw;
        }

        options[id] = val;
    }
}

void
Program::loadCategories(std::string dir, bool recursive, std::string className, bool goodSection)
{
    DIR *dp;
    struct dirent *entry;
    dp=opendir(dir.c_str());

    std::map<std::string, std::string>::iterator it;

    if(dir.at(dir.length()-1)!='/'){
        dir=dir+"/";
    }

    if(dp!=NULL){
        while(entry=readdir(dp)){
            if(strcmp(entry->d_name, ".") != 0 && strcmp(entry->d_name, "..") != 0){
                if(isDir(dir + entry->d_name) == true && recursive == true){
                    it = options.find(entry->d_name);
                    if(it != options.end()) {
                        if(it->second == "true"){
                            loadCategories(dir + entry->d_name, true, entry->d_name, goodSection);
                        }
                    }
                } else{
                    loadContentsHelper(dir + std::string(entry->d_name), className, goodSection);
                }
            }
        }
        (void) closedir(dp);
    }
    else{
        m_rvalue = MISSING_PHRASES_DIRECTORY;
        throw std::logic_error("Couldn't open the directory: " + dir);
    }
}

void
Program::loadContentsHelper(std::string fileName, std::string className, bool goodSection)
{
    bool results = false;
    std::string fileLines;
    finderStruct finderReturn;

    if(!goodSection){
        finderReturn = findLocationCats(className);
    }
    
    std::ifstream in(fileName.c_str());

    if (in.is_open()){
        results = true;
        
        if(!goodSection and !finderReturn.found){
            catMainContainer.push_back(catHolder());
        } else if(goodSection and goodMainContainer.size() == 0){
            goodMainContainer.push_back(catGoodHolder());
        }

        while(getline(in,fileLines)){
            if(!goodSection){
                if(catMainContainer[finderReturn.location].categoryClass == ""){
                    catMainContainer[finderReturn.location].categoryClass = className;
                }

                if (fileLines.find(">,<") != std::string::npos) {
                    catMainContainer[finderReturn.location].multiContainerVec.push_back(fileLines);
                } else{
                    if(fileLines.size() > 0){
                        catMainContainer[finderReturn.location].singleContainerVec.push_back(fileLines);
                    }
                }
            } else{                
                if (fileLines.find(">,<") != std::string::npos) {
                    goodMainContainer[0].multiContainerVec.push_back(fileLines);
                } else{
                    if(fileLines.size() > 0){
                        goodMainContainer[0].singleContainerVec.push_back(fileLines);
                    }
                }
            }
        }
    }
}

finderStruct
Program::findLocationCats(std::string className)
{
    finderStruct returnType;
    
    if(catMainContainer.size() == 0){
        returnType.found = false;
        returnType.location = 0;
        
        return returnType;
    }
    
    for(int i=0;i<catMainContainer.size();i++){
        if(catMainContainer[i].categoryClass == className){
            returnType.found = true;
            returnType.location = i;
            
            return returnType;
        }
    }
    
    returnType.found = false;
    returnType.location = catMainContainer.size();
    
    return returnType;
}

bool
Program::isDir(std::string dir){
    struct stat fileInfo;
    stat(dir.c_str(), &fileInfo);

    if (S_ISDIR(fileInfo.st_mode)){
        return true;
    }else{
        return false;
    }
}

bool
BothAreSpaces(char lhs, char rhs) {
    return (lhs == rhs) && (lhs == ' ');
}

std::string
Program::stripHtmlTags(std::string html)
{
    std::string text;
    std::string original = html;
    
    try {
        for(;;) {
            std::string::size_type  startpos;

            startpos = html.find('<');
            if(startpos == std::string::npos) {
                text += html;
                break;
            }

            if(0 != startpos) {
                text += html.substr(0, startpos);
                html = html.substr(startpos, html.size() - startpos);
                startpos = 0;
            }

            std::string::size_type endpos;
            for(endpos = startpos; endpos < html.size() && html[endpos] != '>'; ++endpos) {
                if(html[endpos] == '"') {
                    endpos++;
                    while(endpos < html.size() && html[endpos] != '"') {
                        endpos++;
                    }
                }
            }

            if(endpos == html.size()) {
                html = html.substr(endpos, html.size() - endpos);
                break;
            } else {
                endpos++;
                html = html.substr(endpos, html.size() - endpos);
            }
        }
    } catch ( const std::exception& ex ) {
        return original;
    }
    
    std::string::iterator new_end = std::unique(text.begin(), text.end(), BothAreSpaces);
    text.erase(new_end, text.end());
    text.erase(std::remove(text.begin(), text.end(), '\n'), text.end());
    text.erase(std::remove(text.begin(), text.end(), '\t'), text.end());

    return text;
}

extern "C" int dllExecute(char * siteContents);

int dllExecute(char * input)
{
    Program program;
    std::string siteContents(input);
    int rvalue = program.execute(siteContents);
    return rvalue;
}

//////////////////////////////////////////////////////////////////////////////