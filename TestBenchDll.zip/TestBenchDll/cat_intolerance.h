/* 
 * File:   cat_intolerance.h
 * Author: jacksalien
 *
 * Created on January 19, 2015, 2:58 PM
 */

#ifndef CAT_INTOLERANCE_H
#define	CAT_INTOLERANCE_H

#include <vector>
#include <string>

std::vector<std::string> cat_intolerance_vec({
"< ARABERSMOVS ><25>",
"< ARYAN ><25>",
"< ARYAN BROTHERHOOD ><25>",
"< ARYAN NATION ><25>",
"< ARYANS ><25>",
"< BIANCO ><25>",
"< BICHAS ><25>",
"< BLACK BASTARD><40>",
"< BLEEKSCHEET ><25>",
"< BUSH BOOGIE ><25>",
"< COON ><25>",
"< FAG ><25>",
"< FAGS ><25>",
"< FLIKKER ><25>",
"< FLIKKERS ><25>",
"< GOOK ><25>",
"< JIGABOO ><25>",
"< JODEN ><25>",
"< KAMELVASKER ><25>",
"< KU KLUX KLAN ><35>",
"< NEGER ><25>",
"< NEGERSVANS ><25>",
"< NEGERSVIN ><25>",
"< NICHTEN ><25>",
"< NIKKER><25>",
"< RAGHEAD ><25>",
"< SPAGHETTIVRETERS ><25>",
"< SPICS ><25>",
"< SPLEETOOG ><25>",
"< WHITEY ><25>",
"< WIGGER ><25>",
"< WOPS ><25>",
"< FAGGOT><25>",
"< HONKEY ><25>",
"< NIGGER ><45>",
"< NIGGERE ><25>",
"< SAMBO ><45>",
"< SPAGGAR ><45>",
"<WHITE SUPREMACY><25>",
"<BLACK SUPREMACY><25>"
});

#endif	/* CAT_INTOLERANCE_H */

