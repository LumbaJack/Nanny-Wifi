/* 
 * File:   cat_drugadvocacy.h
 * Author: jacksalien
 *
 * Created on January 19, 2015, 2:49 PM
 */

#ifndef CAT_DRUGADVOCACY_H
#define	CAT_DRUGADVOCACY_H

#include <vector>
#include <string>

std::vector<std::string> cat_drugadvocacy_vec({
"< AMERICAN CANNABIS SOCIETY ><40>",
"< DROGENPOLITIK ><60>",
"< GANGA ><50>",
"< GANJA ><50>",
"< MARIHUANABELEID ><60>",
"< MARIJUANALAGSTIFTNING ><60>",
"< MARIJUANALOVGIVNING ><60>",
"< MEDICINAL MARIJUANA ><40>",
"< SPLIFF ><60>"
});

#endif	/* CAT_DRUGADVOCACY_H */

